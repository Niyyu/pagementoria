import { HeroSection } from "@/components/sections/HeroSection";
import { BreakingBeliefs } from "@/components/sections/BreakingBeliefs";
import { PainPoints } from "@/components/sections/PainPoints";
import { Solution } from "@/components/sections/Solution";
import { Tracks } from "@/components/sections/Tracks";
import { Promise } from "@/components/sections/Promise";
import { Benefits } from "@/components/sections/Benefits";
import { Mentor } from "@/components/sections/Mentor";
import { FAQ } from "@/components/sections/FAQ";
import { FinalCTA } from "@/components/sections/FinalCTA";
import { FixedCTA } from "@/components/FixedCTA";

const Index = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <FixedCTA />
      <HeroSection />
      <BreakingBeliefs />
      <PainPoints />
      <Solution />
      <Tracks />
      <Promise />
      <Benefits />
      <Mentor />
      <FAQ />
      <FinalCTA />
    </div>
  );
};

export default Index;
