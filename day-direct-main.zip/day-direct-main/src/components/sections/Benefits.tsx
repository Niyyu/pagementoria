import {
  User,
  Calendar,
  Clock,
  HeadphonesIcon,
  Package,
  Megaphone,
  Users,
  VideoIcon,
} from "lucide-react";

const benefits = [
  {
    icon: User,
    title: "Diagnóstico Individual 1:1",
    description: "Análise personalizada do seu momento e objetivos",
  },
  {
    icon: Calendar,
    title: "5 dias de mentoria prática",
    description: "Imersão completa com foco total em resultados",
  },
  {
    icon: Clock,
    title: "2 semanas de acompanhamento",
    description: "Suporte direto na implementação das estratégias",
  },
  {
    icon: HeadphonesIcon,
    title: "Suporte até dominar",
    description: "Acompanhamento contínuo até você alcançar domínio",
  },
  {
    icon: Package,
    title: "Lista de fornecedores",
    description: "Acesso exclusivo aos melhores fornecedores testados",
  },
  {
    icon: Megaphone,
    title: "Setup de anúncios",
    description: "Configuração completa das suas campanhas",
  },
  {
    icon: Users,
    title: "Estratégia de prospecção",
    description: "Métodos validados para encontrar seus clientes",
  },
  {
    icon: VideoIcon,
    title: "Acesso às gravações",
    description: "Revise todo o conteúdo quando precisar",
  },
];

export const Benefits = () => {
  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-4">
          O que você <span className="text-primary">recebe</span>
        </h2>
        <p className="text-xl text-muted-foreground text-center mb-16">
          Um pacote completo para transformar seu negócio
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div
                key={index}
                className="bg-card border border-border rounded-xl p-6 hover:border-primary/50 transition-all duration-300 group hover:shadow-lg"
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <div className="text-primary font-bold text-sm mb-2">
                  {String(index + 1).padStart(2, "0")}
                </div>
                <h3 className="text-xl font-bold mb-2">{benefit.title}</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
