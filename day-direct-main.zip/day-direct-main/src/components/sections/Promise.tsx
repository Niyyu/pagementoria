import { Target } from "lucide-react";

export const Promise = () => {
  return (
    <section className="py-24 px-6 bg-gradient-to-br from-primary/10 via-background to-accent/10">
      <div className="max-w-5xl mx-auto">
        <div className="bg-card border-2 border-primary/50 rounded-3xl p-12 md:p-16 text-center shadow-[0_0_50px_rgba(251,191,36,0.2)]">
          <div className="flex justify-center mb-8">
            <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center">
              <Target className="w-10 h-10 text-primary" />
            </div>
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold leading-tight mb-6">
            Meu compromisso:
          </h2>
          <p className="text-3xl md:text-4xl font-bold text-primary leading-tight">
            Te levar aos seus primeiros R$10.000 em até 45 dias.
          </p>
        </div>
      </div>
    </section>
  );
};
