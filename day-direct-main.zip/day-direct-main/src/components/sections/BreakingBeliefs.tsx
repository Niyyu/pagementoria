export const BreakingBeliefs = () => {
  return (
    <section className="py-20 px-6 bg-card/50">
      <div className="max-w-4xl mx-auto text-center">
        <div className="border-2 border-primary/30 rounded-2xl p-12 bg-gradient-to-br from-card to-muted/50 shadow-lg">
          <h2 className="text-4xl md:text-5xl font-bold leading-tight">
            Você não precisa de{" "}
            <span className="text-primary">mais um curso</span>
          </h2>
          <p className="text-xl text-muted-foreground mt-6 leading-relaxed">
            O que você precisa é de clareza, estratégia e acompanhamento real para transformar conhecimento em resultado.
          </p>
        </div>
      </div>
    </section>
  );
};
