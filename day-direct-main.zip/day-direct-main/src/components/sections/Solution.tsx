export const Solution = () => {
  return (
    <section className="py-24 px-6 bg-card/30">
      <div className="max-w-4xl mx-auto text-center space-y-8">
        <h2 className="text-4xl md:text-5xl font-bold leading-tight">
          A solução: a Mentoria{" "}
          <span className="text-primary">10K em 45 Dias</span>
        </h2>
        
        <p className="text-2xl text-muted-foreground leading-relaxed">
          Mentoria prática, 5 dias mão na massa + 2 semanas de acompanhamento real.
          <br />
          <span className="text-foreground font-semibold">Você escolhe sua trilha.</span>
        </p>
      </div>
    </section>
  );
};
