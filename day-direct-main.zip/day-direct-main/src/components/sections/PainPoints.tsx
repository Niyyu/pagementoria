import { X } from "lucide-react";

const painPoints = [
  "Tentar fazer tudo sozinho",
  "Copiar estratégias sem resultado",
  "Excesso de informação",
  "Pular de promessa em promessa",
  "Comprar cursos sem acompanhamento",
  "Não saber o próximo passo",
];

export const PainPoints = () => {
  return (
    <section className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">
          Os sinais de que você está <span className="text-primary">travado</span>
        </h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {painPoints.map((point, index) => (
            <div
              key={index}
              className="bg-card border border-border rounded-xl p-6 hover:border-primary/50 transition-all duration-300 group"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-destructive/20 flex items-center justify-center group-hover:bg-destructive/30 transition-colors">
                  <X className="w-4 h-4 text-destructive" />
                </div>
                <p className="text-lg font-medium leading-relaxed">{point}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
