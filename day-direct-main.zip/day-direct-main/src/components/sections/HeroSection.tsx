import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export const HeroSection = () => {
  const handleCTA = () => {
    window.open("https://wa.me/seu-numero-aqui", "_blank");
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center px-6 py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-muted opacity-80" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(251,191,36,0.05),transparent_50%)]" />
      
      <div className="relative max-w-5xl mx-auto text-center space-y-8 animate-fade-in">
        <div className="space-y-4">
          <h1 className="text-5xl md:text-7xl font-bold leading-tight tracking-tight">
            Você não precisa de
            <br />
            <span className="text-primary">mais um curso.</span>
          </h1>
          <h2 className="text-4xl md:text-6xl font-bold leading-tight">
            Você precisa de <span className="text-primary">DIREÇÃO.</span>
          </h2>
        </div>

        <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
          Negócio digital real, 10k em 45 dias, duas trilhas — Mercado Livre e Tráfego Pago.
        </p>

        <div className="pt-8">
          <Button
            onClick={handleCTA}
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-accent shadow-[0_0_30px_rgba(251,191,36,0.3)] hover:shadow-[0_0_40px_rgba(251,191,36,0.5)] transition-all duration-300 font-semibold text-lg px-10 py-7"
          >
            Quero receber meu diagnóstico
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  );
};
