import { CheckCircle } from "lucide-react";

export const Mentor = () => {
  return (
    <section className="py-24 px-6 bg-card/30">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">
          Sobre o <span className="text-primary">Mentor</span>
        </h2>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <h3 className="text-3xl font-bold mb-6">Bruno Borrego</h3>
            
            <p className="text-xl text-muted-foreground leading-relaxed mb-8">
              Sou Bruno Borrego, especialista em <span className="text-primary font-semibold">Mercado Livre</span> e{" "}
              <span className="text-primary font-semibold">Tráfego Pago</span>. Já ajudei centenas de pessoas a criarem resultados reais.
            </p>

            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-success flex-shrink-0 mt-1" />
                <p className="text-lg">Gerencio operações de e-commerce de alto volume</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-success flex-shrink-0 mt-1" />
                <p className="text-lg">Produzo resultados consistentes para empresas</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-success flex-shrink-0 mt-1" />
                <p className="text-lg">Ensino pessoas comuns a faturarem seus primeiros R$10.000</p>
              </div>
            </div>
          </div>

          <div className="order-1 md:order-2">
            <div className="aspect-square rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 border-2 border-primary/30 overflow-hidden">
              <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                <div className="text-center p-8">
                  <p className="text-lg">Foto profissional do Bruno Borrego</p>
                  <p className="text-sm mt-2">(Adicione sua foto aqui)</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
