import { Button } from "@/components/ui/button";
import { ArrowRight, Clock } from "lucide-react";

export const FinalCTA = () => {
  const handleCTA = () => {
    window.open("https://wa.me/seu-numero-aqui", "_blank");
  };

  return (
    <section className="py-32 px-6 bg-gradient-to-br from-primary/10 via-background to-accent/10">
      <div className="max-w-4xl mx-auto text-center space-y-8">
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center animate-pulse">
            <Clock className="w-8 h-8 text-primary" />
          </div>
        </div>

        <h2 className="text-4xl md:text-6xl font-bold leading-tight">
          Quer furar a fila?
        </h2>
        
        <p className="text-2xl md:text-3xl text-muted-foreground leading-relaxed">
          Fale direto com a equipe agora.
          <br />
          <span className="text-primary font-semibold">Resposta em menos de 2 minutos.</span>
        </p>

        <div className="pt-8">
          <Button
            onClick={handleCTA}
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-accent shadow-[0_0_40px_rgba(251,191,36,0.3)] hover:shadow-[0_0_50px_rgba(251,191,36,0.5)] transition-all duration-300 font-bold text-xl px-12 py-8"
          >
            Quero fazer minha aplicação
            <ArrowRight className="ml-3 h-6 w-6" />
          </Button>
        </div>

        <p className="text-sm text-muted-foreground pt-4">
          Vagas limitadas • Acompanhamento individualizado
        </p>
      </div>
    </section>
  );
};
