import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "E se eu não tiver tempo?",
    answer:
      "A mentoria é desenhada para pessoas ocupadas. Com apenas 2-3 horas por dia você consegue implementar tudo. O acompanhamento de 2 semanas garante que você avance no seu ritmo.",
  },
  {
    question: "Funciona do zero?",
    answer:
      "Sim! A mentoria foi criada justamente para quem está começando. Você vai do zero até os primeiros R$10.000 com acompanhamento completo em cada etapa.",
  },
  {
    question: "Já comprei curso e não funcionou",
    answer:
      "Cursos não têm acompanhamento individual. Aqui você tem diagnóstico 1:1, mentoria prática de 5 dias e 2 semanas de suporte direto. É completamente diferente.",
  },
  {
    question: "Não tenho produto",
    answer:
      "Não precisa! Na trilha Mercado Livre você aprende revenda, dropshipping ou produto próprio. Na trilha Tráfego Pago você pode criar uma agência ou escalar negócios.",
  },
  {
    question: "Vergonha de aparecer",
    answer:
      "Nenhuma das trilhas exige que você apareça. Mercado Livre é anúncios de produtos. Tráfego Pago é gestão de campanhas. Você fica nos bastidores.",
  },
  {
    question: "Tenho negócio local",
    answer:
      "Perfeito! A trilha Tráfego Pago é ideal para escalar negócios locais com Google Ads e Meta Ads. Você vai trazer clientes qualificados para seu negócio.",
  },
  {
    question: "E se eu não gostar?",
    answer:
      "Você terá uma sessão de diagnóstico 1:1 antes de começar. Ali você vai entender exatamente como funciona e decidir se é para você. Sem surpresas.",
  },
];

export const FAQ = () => {
  return (
    <section className="py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-4">
          Dúvidas que todo mundo tem
        </h2>
        <p className="text-xl text-muted-foreground text-center mb-16">
          Respondendo as perguntas mais frequentes
        </p>

        <Accordion type="single" collapsible className="space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem
              key={index}
              value={`item-${index}`}
              className="bg-card border border-border rounded-xl px-6 hover:border-primary/50 transition-colors"
            >
              <AccordionTrigger className="text-left text-lg font-semibold py-6 hover:no-underline">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground text-base leading-relaxed pb-6">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
};
