import { Button } from "@/components/ui/button";
import { Check, ShoppingCart, TrendingUp } from "lucide-react";

const mercadoLivreItems = [
  "Começar a vender",
  "Produtos vencedores",
  "Análise de concorrência",
  "Lista de fornecedores",
  "Anúncios que convertem",
  "Revenda / dropshipping / produto próprio",
  "Escala e catálogo",
];

const trafegoItems = [
  "Google Ads",
  "Meta Ads",
  "Escalar negócio físico ou online",
  "Criar agência",
  "Prospecção",
  "Gestão de tráfego",
  "Operação prática",
];

export const Tracks = () => {
  const handleMercadoLivre = () => {
    window.open("https://wa.me/seu-numero-aqui?text=Quero%20a%20trilha%20Mercado%20Livre", "_blank");
  };

  const handleTrafego = () => {
    window.open("https://wa.me/seu-numero-aqui?text=Quero%20a%20trilha%20Tráfego%20Pago", "_blank");
  };

  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-4">
          Escolha sua <span className="text-primary">trilha</span>
        </h2>
        <p className="text-xl text-muted-foreground text-center mb-16">
          Duas jornadas distintas, um único objetivo: seus primeiros R$10.000
        </p>

        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Mercado Livre Track */}
          <div className="bg-card border-2 border-border rounded-2xl p-8 hover:border-primary/50 transition-all duration-300 hover:shadow-[0_0_30px_rgba(251,191,36,0.2)] group animate-slide-in-left">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                <ShoppingCart className="w-7 h-7 text-primary" />
              </div>
              <div>
                <h3 className="text-3xl font-bold">Mercado Livre</h3>
                <p className="text-muted-foreground">E-commerce Domination</p>
              </div>
            </div>

            <div className="space-y-4 mb-8">
              {mercadoLivreItems.map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-success/20 flex items-center justify-center mt-0.5">
                    <Check className="w-4 h-4 text-success" />
                  </div>
                  <span className="text-lg leading-relaxed">{item}</span>
                </div>
              ))}
            </div>

            <Button
              onClick={handleMercadoLivre}
              className="w-full bg-primary text-primary-foreground hover:bg-accent font-semibold text-lg py-6"
              size="lg"
            >
              Quero a trilha Mercado Livre
            </Button>
          </div>

          {/* Tráfego Pago Track */}
          <div className="bg-card border-2 border-border rounded-2xl p-8 hover:border-accent/50 transition-all duration-300 hover:shadow-[0_0_30px_rgba(251,191,36,0.2)] group animate-slide-in-right">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-14 h-14 rounded-xl bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                <TrendingUp className="w-7 h-7 text-accent" />
              </div>
              <div>
                <h3 className="text-3xl font-bold">Tráfego Pago</h3>
                <p className="text-muted-foreground">Paid Ads Mastery</p>
              </div>
            </div>

            <div className="space-y-4 mb-8">
              {trafegoItems.map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-success/20 flex items-center justify-center mt-0.5">
                    <Check className="w-4 h-4 text-success" />
                  </div>
                  <span className="text-lg leading-relaxed">{item}</span>
                </div>
              ))}
            </div>

            <Button
              onClick={handleTrafego}
              className="w-full bg-accent text-accent-foreground hover:bg-primary font-semibold text-lg py-6"
              size="lg"
            >
              Quero a trilha Tráfego Pago
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
