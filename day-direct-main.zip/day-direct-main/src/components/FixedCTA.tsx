import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export const FixedCTA = () => {
  const handleClick = () => {
    window.open("https://wa.me/seu-numero-aqui", "_blank");
  };

  return (
    <div className="fixed bottom-8 right-8 z-50 hidden md:block animate-fade-in">
      <Button
        onClick={handleClick}
        size="lg"
        className="bg-primary text-primary-foreground hover:bg-accent shadow-[0_0_30px_rgba(251,191,36,0.3)] hover:shadow-[0_0_40px_rgba(251,191,36,0.5)] transition-all duration-300 font-semibold text-lg px-8 py-6"
      >
        Quero fazer minha aplicação
        <ArrowRight className="ml-2 h-5 w-5" />
      </Button>
    </div>
  );
};
